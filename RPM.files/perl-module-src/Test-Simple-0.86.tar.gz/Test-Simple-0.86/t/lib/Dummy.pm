package Dummy;
# $Id$

$VERSION = '0.01';

1;
