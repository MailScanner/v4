#
#   MailScanner - SMTP E-Mail Virus Scanner
#   Copyright (C) 2002  Julian Field
#
#   $Id: MyExample.pm,v 1.1.2.1 2004/03/23 09:23:43 jkf Exp $
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#   The author, Julian Field, can be contacted by email at
#      Jules@JulianField.net
#   or by paper mail at
#      Julian Field
#      Dept of Electronics & Computer Science
#      University of Southampton
#      Southampton
#      SO17 1BJ
#      United Kingdom
#

use Mail::IMAPClient;

package MailScanner::CustomConfig;

use strict 'vars';
use strict 'refs';
no  strict 'subs'; # Allow bare words for parameter %'s

use vars qw($VERSION);

### The package version, both in 1.23 style *and* usable by MakeMaker:
$VERSION = substr q$Revision: 1.1.2.1 $, 10;

#
# These are the custom functions that you can write to produce a value
# for any configuration keyword that you want to do clever things such
# as retrieve values from a database.
#
# Your function may be passed a "message" object, and must return
# a legal value for the configuration parameter. No checking will be
# done on the result, for extra speed. If you want to find out what
# there is in a "message" object, look at Message.pm as they are all
# listed there.
#
# You must handle the case when no "message" object is passed to your
# function. In this case it should return a sensible default value.
#
# Return value: You must return the internal form of the result values.
#               For example, if you are producing a yes or no value,
#               you return 1 or 0. To find all the internal values
#               look in ConfigDefs.pl.
#
# For each function "FooValue" that you write, there needs to be a
# function "InitFooValue" which will be called when the configuration
# file is read. In the InitFooValue function, you will need to set up
# any global state such as create database connections, read more
# configuration files and so on.
#


my $JunkMailboxName = 'Auto-Junk';

my %user2password = ();
my %user2server   = ();


sub InitIMAPspam {
  my($filename) = @_;

  MailScanner::Log::InfoLog("Initialising IMAPspam");

  my $fh = new FileHandle;
  unless ($fh->open("<$filename")) {
    MailScanner::Log::WarnLog("IMAPspam: Could not open configuration file \"$filename\"");
    return;
  }

  # Read in the config file which contains lines like
  # domainname.com
  # or
  # username:password@hostname
  # 
  # The keys of the hashes are username@domainname
  # The values of the hashes are the password and the IMAP hostname.

  my $currentdomain = "";
  my $imapcount = 0;
  my $domaincount = 0;
  print STDERR "About to read contents of $fh\n";
  while(defined($_=<$fh>)) {
    chomp;
    print STDERR "Read \"$_\"\n";
    s/^#//;
    s/^\s*//g;
    s/\s*$//g;
    next if /^$/;

    if (/^.*:.*@/) {
      # This is a username:password@hostname line
      my ($username, $password, $hostname) = ($1, $2, $3)
        if /^([^:]+):(.*)@([^@]+)$/;
      $user2password{$username . '@' . $currentdomain} = $password;
      $user2server{$username   . '@' . $currentdomain} = $hostname;
      $imapcount++;
      print STDERR "Username:\t\"$username\"\t\"$password\"\t\"$hostname\"\n";
    } else {
      $currentdomain = $_;
      $domaincount++;
      print STDERR "New domain is \"$currentdomain\"\n";
    }
  }
  MailScanner::Log::InfoLog("IMAPspam: Read imap details for $imapcount users in $domaincount domains");

  $fh->close;
}

sub EndIMAPspam {
  # This function could log total stats, close databases, etc.
  MailScanner::Log::InfoLog("Ending IMAPspam");
}

# This will return "store" for any relevant messages, as well as saving the
# message in RFC822 format to the correct imap server for the user/domain.
# computer.
sub IMAPspam {
  my($message) = @_;

  print STDERR "In IMAPspam, message is $message\n";
  return 'store' unless $message; # Default if no message passed in
  return 'store' unless $message->{to};

  # Read in the message and process it for cr/lf terminations.
  # But this is slow so only do it for relevant messages.
  my @userlist     = ();
  my @passwordlist = ();
  my @serverlist   = ();
  my $to = "";

  foreach $to (@{$message->{to}}) {
    my ($user, $domain) = split(/@/, $to, 2);
    print "Reading to address \"$to\"\n";
    if ($domain && $user2server{$user . '@' . $domain}) {
      print STDERR "Found user $user at $domain\n";
      push @userlist, $user;
      push @passwordlist, $user2password{$user . '@' . $domain};
      push @serverlist,   $user2server{$user   . '@' . $domain};
    }
  }
  return 'store' unless @userlist && @passwordlist && @serverlist;

  # We have a relevant message, so set the line-endings with a temp file
  print STDERR "We have a relevant message\n";
  my $tmphandle = new FileHandle;
  my $tmpname   = "/tmp/IMAPspam.tmp.$$";
  unless ($tmphandle->open(">$tmpname")) {
    MailScanner::Log::WarnLog("Could not create temp file $tmpname");
    return 'store';
  }
  
  $message->{store}->WriteEntireMessage($message, $tmphandle);
  $tmphandle->close;
  $tmphandle = new FileHandle;
  $tmphandle->open("<$tmpname") or MailScanner::Log::WarnLog("Could not read back temp file $tmpname");
  
  # Now read it into a string, converting line endings as we go
  my $message = "";
  while(defined($_=<$tmphandle>)) {
    chomp;
    s/$/\r\n/;
    $message .= $_;
  }
  $tmphandle->close;
  unlink $tmpname;

  print STDERR "I now have the message in tmpname, length = " . length($message) . "\n";

  # Now do the IMAP work to append the message to the mailbox
  my $imap;
  my($i, $user, $pass, $serv);
  for ($i=0; $i<@userlist; $i++) {
    $user = $userlist[$i];
    $pass = $passwordlist[$i];
    $serv = $serverlist[$i];
    print STDERR "Saving message to $JunkMailboxName as $user on $serv\n";
    next unless $serv && $user;
    $imap = Mail::IMAPClient->new(Server   => $serv,
                                  User     => $user,
                                  Password => $pass);
    unless ($imap) {
      print STDERR "IMAP connection failed\n";
      MailScanner::Log::WarnLog("Could not connect to IMAP server \"%s\" as user \"%s\", error was %s!", $serv, $user, $@);
      next;
    }
    unless ($imap->select($JunkMailboxName)) {
      print STDERR "IMAP mailbox does not exist, creating it...\n";
      # Mailbox did not exist, attempt to create it
      unless ($imap->create($JunkMailboxName)) {
        print STDERR "Could not create it either :-(\n";
        # Couldn't create it, something's wrong.
        MailScanner::Log::WarnLog("Could not create %s as %s on %s", $JunkMailboxName, $user, $serv);
        next;
      }
      $imap->select($JunkMailboxName);
    }
    unless ($imap->append($JunkMailboxName, $message)) {
      print STDERR "Message append failed too\n";
      # Append failed. Oh dear :-(
      MailScanner::Log::WarnLog("Could not append new message to %s as %s on %s", $JunkMailboxName, $user, $serv);
      next;
    }
  }

  print STDERR "All done for this message.\n\n\n";
  return 'store';
}

1;

